package com.exercise;

import io.vertx.core.AbstractVerticle;

import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

/**
 * @author <a href="http://tfox.org">Tim Fox</a>
 */
public class Example extends AbstractVerticle {
	
	

	@Override
	public void start() throws Exception {
	Router router = Router.router(vertx);
	vertx.createHttpServer().requestHandler(router).listen(8000);
	System.out.println("server started at 8000");
	router.route().handler(BodyHandler.create());
	router.route("/").handler(routingContext -> {
	JsonObject json = new JsonObject()
	.put("message","hello world");
	routingContext.response()
	.putHeader("content-type","application/json; charset=UTF8")
	.end(json.encodePrettily() );
	});
	}
}


  