package com.exercise;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.CorsHandler;

public class Corshandler extends AbstractVerticle {
@Override
public void start() throws Exception {
Router router = Router.router(vertx);
vertx.createHttpServer().requestHandler(router).listen(8095);
System.out.println("server started at 8095");
router.route()
.handler(
CorsHandler.create("vertx\\.io")
.allowedMethod(HttpMethod.GET));



router.route().handler(ctx -> {



JsonObject json = new JsonObject()
.put("message","hai");
ctx.response()
.putHeader("content-type","application/json; charset=UTF8")
.end(json.encodePrettily() );



});
}



}
