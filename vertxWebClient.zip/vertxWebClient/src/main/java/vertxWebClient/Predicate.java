package vertxWebClient;

import java.util.function.Function;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.client.predicate.ResponsePredicate;
import io.vertx.ext.web.client.predicate.ResponsePredicateResult;


public class Predicate extends AbstractVerticle{

	
	public static void main(String[] args) {



		Vertx vertx=Vertx.vertx();
		Router router = Router.router(vertx);
		WebClient client = WebClient.create(vertx);



		client
		  .get(8080, "myserver.mycompany.com", "/some-uri")
		  .expect(ResponsePredicate.SC_SUCCESS)
		  .expect(ResponsePredicate.JSON)
		  .send()
		  .onSuccess(res -> {
		    // Safely decode the body as a json object
		    JsonObject body = res.bodyAsJsonObject();
		    System.out.println(
		      "Received response with status code" +
		        res.statusCode() +
		        " with body " +
		        body);
		  })
		  .onFailure(err ->
		    System.out.println("Something went wrong " + err.getMessage()));
		}
		}